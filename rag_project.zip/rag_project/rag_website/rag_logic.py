import numpy as np
from heap_ranker import heap_top_k

def chunk_text(text, chunk_size=200):
    words = text.split()
    return [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)] #chunks are made of fixed size

def embed(text, dim=50):
    rng = np.random.RandomState(abs(hash(text)) % (2**32)) #text hash is converted to embeddings
    return rng.randn(dim)

def cosine_similarity(a, b):
    return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))

def retrieve_top_k(question, chunks, k=5):
    q_vec = embed(question)
    scored_chunks = []

    for chunk in chunks:
        sim = cosine_similarity(q_vec, embed(chunk))
        scored_chunks.append({
            "text": chunk,
            "similarity": sim
        })

    ranked = heap_top_k(scored_chunks, question, k)
    return ranked

import re

def extract_answer(ranked_chunks, question):
    # Combine top-ranked chunks
    combined_text = " ".join(item[1]["text"] for item in ranked_chunks)

    # Split into sentences
    sentences = re.split(r"[.?!]", combined_text)

    # Clean question keywords
    q_words = [
        w.lower()
        for w in re.findall(r"\w+", question)
        if len(w) > 3
    ]

    if not q_words:
        return "Answer not found in the given documents."
 
    scored_sentences = []

    for s in sentences:
        s_lower = s.lower()
        score = sum(1 for w in q_words if w in s_lower)

        if score > 0:
            scored_sentences.append((score, s.strip()))

    # No relevant sentence found
    if not scored_sentences:
        return "Answer not found in the given documents."

    # Sort sentences by relevance
    scored_sentences.sort(reverse=True, key=lambda x: x[0])

    # Return top 1–2 sentences as answer
    answer_sentences = [s for _, s in scored_sentences[:2]]

    return ". ".join(answer_sentences) + "."

