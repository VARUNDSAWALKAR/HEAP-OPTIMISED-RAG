import heapq
import re

def keyword_overlap_score(query, text):
    q_words = set(re.findall(r"\w+", query.lower()))
    t_words = set(re.findall(r"\w+", text.lower()))
    return len(q_words & t_words)

def heap_top_k(chunks, query, k=5):
    heap = []
    q_clean = query.lower().replace("?", "")

    for chunk in chunks:
        text = chunk["text"]
        sim = chunk["similarity"]
        overlap = keyword_overlap_score(query, text)

        text_lower = text.lower()

        definition_boost = 0
        if q_clean.replace("what is", "").strip() in text_lower and "refer to" in text_lower:
            definition_boost = 5

        final_score = (0.6 * sim) + (0.3 * overlap) + definition_boost
        item = (final_score, chunk)

        if len(heap) < k:
            heapq.heappush(heap, item)
        else:
            if final_score > heap[0][0]:
                heapq.heapreplace(heap, item)

    return sorted(heap, key=lambda x: x[0], reverse=True)
