import streamlit as st
from rag_logic import chunk_text, retrieve_top_k, extract_answer

# ---------- PAGE CONFIG ----------
st.set_page_config(
    page_title="Heap-Optimized RAG System",
    page_icon="RVCE :",
    layout="wide"
)

# ---------- CUSTOM CSS ----------
st.markdown("""
<style>
body {
    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);
}

.main {
    background-color: transparent;
}

h1, h2, h3 {
    color: #EAF2F8;
}

.section-card {
    background-color: #1c2833;
    padding: 25px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0px 0px 12px rgba(0,0,0,0.4);
}

.answer-box {
    background-color: #145a32;
    padding: 20px;
    border-radius: 10px;
    font-size: 18px;
    color: #eafaf1;
    box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
}

.chunk-box {
    background-color: #17202a;
    padding: 15px;
    border-radius: 10px;
    margin-bottom: 10px;
    color: #d6eaf8;
    border-left: 5px solid #3498db;
}
</style>
""", unsafe_allow_html=True)

# ---------- SIDEBAR ----------
st.sidebar.title(" RVCE Document Input")
st.sidebar.write("Upload text documents for retrieval.")

uploaded_files = st.sidebar.file_uploader(
    "Upload TXT files",
    type=["txt"],
    accept_multiple_files=True
)

st.sidebar.markdown("---")
st.sidebar.write("⚙️ **System Settings**")
TOP_K = st.sidebar.slider("Top-K Chunks", 3, 10, 5)

# ---------- HEADER ----------
st.markdown("<h1>Heap-Optimized Retrieval-Augmented Generation</h1>", unsafe_allow_html=True)
st.markdown(
    "<p style='color:#d5dbdb;'>"
    "A DSA-based system demonstrating efficient Top-K document retrieval "
    "using a min-heap to improve contextual relevance in RAG pipelines."
    "</p>",
    unsafe_allow_html=True
)

# ---------- DOCUMENT PROCESSING ----------
if uploaded_files:
    full_text = ""
    for file in uploaded_files:
        full_text += file.read().decode("utf-8", errors="ignore") + " "

    chunks = chunk_text(full_text)

    st.markdown(
        f"<div class='section-card'><b>📄 Documents processed:</b> "
        f"{len(uploaded_files)} files<br>"
        f"<b>🧩 Total chunks created:</b> {len(chunks)}</div>",
        unsafe_allow_html=True
    )

    # ---------- QUESTION ----------
    st.markdown("<div class='section-card'>", unsafe_allow_html=True)
    st.subheader("🔍 Ask a Question")
    question = st.text_input("Enter your question (e.g., WHAT IS BIOHAZARDS?)")
    st.markdown("</div>", unsafe_allow_html=True)

    if question:
        ranked_chunks = retrieve_top_k(question, chunks, k=TOP_K)

        # ---------- RETRIEVED CHUNKS ----------
        st.markdown("<div class='section-card'>", unsafe_allow_html=True)
        st.subheader("📊 Top-K Retrieved Chunks (Heap-Ranked)")

        for i, (score, item) in enumerate(ranked_chunks, start=1):
            st.markdown(
                f"<div class='chunk-box'><b>Rank {i}</b> "
                f"| Score: {round(score, 2)}<br><br>{item['text']}</div>",
                unsafe_allow_html=True
            )

        st.markdown("</div>", unsafe_allow_html=True)

        # ---------- FINAL ANSWER ----------
        answer = extract_answer(ranked_chunks, question)

        st.markdown("<div class='section-card'>", unsafe_allow_html=True)
        st.subheader("✅ Final Answer")
        st.markdown(f"<div class='answer-box'>{answer}</div>", unsafe_allow_html=True)
        st.markdown("</div>", unsafe_allow_html=True)

else:
    st.info("👈 Upload TXT documents from the sidebar to begin.")
